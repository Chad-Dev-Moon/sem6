#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <set>
#include <map>

using namespace std;

struct Production {
    char left;
    string right;
};

class LL1Verifier {
private:
    set<char> nonTerminals;
    set<char> terminals;
    char startSymbol;
    vector<Production> productions;
    
    map<char, set<char>> firstSets;
    map<char, set<char>> followSets;
    vector<Production> convertedProductions;
    
    const char EPSILON = 'e';
    const char END_MARKER = '$';
    
public:
    void readGrammarFromFile(const string& filename) {
        ifstream file(filename);
        
        int numNonTerminals, numTerminals, numProductions;
        
        file >> numNonTerminals;
        for (int i = 0; i < numNonTerminals; i++) {
            char nt;
            file >> nt;
            nonTerminals.insert(nt);
            firstSets[nt].clear();
            followSets[nt].clear();
        }
        
        file >> numTerminals;
        for (int i = 0; i < numTerminals; i++) {
            char t;
            file >> t;
            if (t != EPSILON) {
                terminals.insert(t);
            }
        }
        
        file >> startSymbol;
        
        file >> numProductions;
        file.ignore();
        for (int i = 0; i < numProductions; i++) {
            string line;
            getline(file, line);
            
            size_t arrowPos = line.find("->");
            if (arrowPos != string::npos) {
                char left = line[0];
                string right = line.substr(arrowPos + 2);
                
                while (!right.empty() && right[0] == ' ') right = right.substr(1);
                while (!right.empty() && right.back() == ' ') right.pop_back();
                
                productions.push_back({left, right});
            }
        }
        
        file.close();
    }
    
    void displayGrammar() {
        cout << "\n===== Original Grammar =====\n";
        cout << "Non-terminals: { ";
        for (char nt : nonTerminals) cout << nt << " ";
        cout << "}\nTerminals: { ";
        for (char t : terminals) cout << t << " ";
        cout << "}\nStart: " << startSymbol << "\n\nProductions:\n";
        for (const auto& prod : productions) {
            cout << "  " << prod.left << " -> ";
            if (prod.right == "e") cout << "ε";
            else cout << prod.right;
            cout << "\n";
        }
        cout << "=============================\n\n";
    }
    
    void computeFirst() {
        for (char t : terminals) {
            firstSets[t].insert(t);
        }
        
        bool changed = true;
        while (changed) {
            changed = false;
            
            for (const auto& prod : productions) {
                char left = prod.left;
                string right = prod.right;
                
                set<char> oldFirst = firstSets[left];
                
                if (right == "e") {
                    firstSets[left].insert(EPSILON);
                } else {
                    bool allHaveEpsilon = true;
                    for (char symbol : right) {
                        if (terminals.find(symbol) != terminals.end()) {
                            firstSets[left].insert(symbol);
                            allHaveEpsilon = false;
                            break;
                        } else {
                            for (char c : firstSets[symbol]) {
                                if (c != EPSILON) {
                                    firstSets[left].insert(c);
                                }
                            }
                            
                            if (firstSets[symbol].find(EPSILON) == firstSets[symbol].end()) {
                                allHaveEpsilon = false;
                                break;
                            }
                        }
                    }
                    
                    if (allHaveEpsilon) {
                        firstSets[left].insert(EPSILON);
                    }
                }
                
                if (firstSets[left] != oldFirst) {
                    changed = true;
                }
            }
        }
    }
    
    void computeFollow() {
        followSets[startSymbol].insert(END_MARKER);
        
        bool changed = true;
        while (changed) {
            changed = false;
            
            for (const auto& prod : productions) {
                char left = prod.left;
                string right = prod.right;
                
                for (size_t i = 0; i < right.length(); i++) {
                    char symbol = right[i];
                    
                    if (nonTerminals.find(symbol) == nonTerminals.end()) {
                        continue;
                    }
                    
                    set<char> oldFollow = followSets[symbol];
                    
                    bool allHaveEpsilon = true;
                    for (size_t j = i + 1; j < right.length(); j++) {
                        char next = right[j];
                        
                        if (terminals.find(next) != terminals.end()) {
                            followSets[symbol].insert(next);
                            allHaveEpsilon = false;
                            break;
                        } else {
                            for (char c : firstSets[next]) {
                                if (c != EPSILON) {
                                    followSets[symbol].insert(c);
                                }
                            }
                            
                            if (firstSets[next].find(EPSILON) == firstSets[next].end()) {
                                allHaveEpsilon = false;
                                break;
                            }
                        }
                    }
                    
                    if (allHaveEpsilon) {
                        for (char c : followSets[left]) {
                            followSets[symbol].insert(c);
                        }
                    }
                    
                    if (followSets[symbol] != oldFollow) {
                        changed = true;
                    }
                }
            }
        }
    }
    
    void displayFirstFollowSets() {
        cout << "\nFIRST Sets:\n";
        for (char nt : nonTerminals) {
            cout << "FIRST(" << nt << ") = { ";
            for (char c : firstSets[nt]) {
                if (c == EPSILON) cout << "ε ";
                else cout << c << " ";
            }
            cout << "}\n";
        }
        
        cout << "\nFOLLOW Sets:\n";
        for (char nt : nonTerminals) {
            cout << "FOLLOW(" << nt << ") = { ";
            for (char c : followSets[nt]) {
                if (c == END_MARKER) cout << "$ ";
                else cout << c << " ";
            }
            cout << "}\n";
        }
    }
    
    set<char> getFirstOfString(const string& str) {
        set<char> result;
        
        bool allHaveEpsilon = true;
        for (char symbol : str) {
            if (terminals.find(symbol) != terminals.end()) {
                result.insert(symbol);
                allHaveEpsilon = false;
                break;
            } else {
                for (char c : firstSets[symbol]) {
                    if (c != EPSILON) {
                        result.insert(c);
                    }
                }
                
                if (firstSets[symbol].find(EPSILON) == firstSets[symbol].end()) {
                    allHaveEpsilon = false;
                    break;
                }
            }
        }
        
        if (allHaveEpsilon) {
            result.insert(EPSILON);
        }
        
        return result;
    }
    
    bool checkLL1Conflicts() {
        cout << "\n===== LL(1) Conflict Check =====\n";
        bool hasConflict = false;
        
        for (size_t p1 = 0; p1 < productions.size(); p1++) {
            for (size_t p2 = p1 + 1; p2 < productions.size(); p2++) {
                if (productions[p1].left != productions[p2].left) continue;
                
                string right1 = productions[p1].right;
                string right2 = productions[p2].right;
                
                set<char> first1 = getFirstOfString(right1);
                set<char> first2 = getFirstOfString(right2);
                
                for (char c : first1) {
                    if (c != EPSILON && first2.find(c) != first2.end()) {
                        cout << "CONFLICT: " << productions[p1].left << " -> " 
                             << right1 << " and " << productions[p1].left << " -> " 
                             << right2 << "\n";
                        cout << "  Common symbol in FIRST: " << c << "\n";
                        hasConflict = true;
                    }
                }
            }
        }
        
        if (!hasConflict) {
            cout << "No conflicts found - Grammar is LL(1) compatible!\n";
        }
        
        cout << "================================\n";
        return !hasConflict;
    }
    
    void eliminateLeftRecursion() {
        cout << "\n===== Eliminating Left Recursion =====\n";
        
        convertedProductions.clear();
        bool hasRecursion = false;
        
        for (char A : nonTerminals) {
            bool hasDirectRecursion = false;
            
            for (const auto& prod : productions) {
                if (prod.left == A && !prod.right.empty() && prod.right[0] == A) {
                    hasDirectRecursion = true;
                    hasRecursion = true;
                    break;
                }
            }
            
            if (hasDirectRecursion) {
                cout << "Left recursion found in " << A << ", converting...\n";
                
                string APrime = string(1, A) + "'";
                
                for (const auto& prod : productions) {
                    if (prod.left == A) {
                        if (!prod.right.empty() && prod.right[0] == A) {
                            // A -> A alpha becomes A' -> alpha A'
                            string newRight = prod.right.substr(1) + APrime;
                            convertedProductions.push_back({APrime[0], newRight});
                        } else {
                            // A -> beta becomes A -> beta A'
                            string newRight = prod.right + APrime;
                            convertedProductions.push_back({A, newRight});
                        }
                    }
                }
                
                // A' -> epsilon
                convertedProductions.push_back({APrime[0], "e"});
            } else {
                for (const auto& prod : productions) {
                    if (prod.left == A) {
                        convertedProductions.push_back(prod);
                    }
                }
            }
        }
        
        if (!hasRecursion) {
            cout << "No left recursion found!\n";
        }
        cout << "====================================\n";
    }
    
    void displayConvertedGrammar() {
        if (!convertedProductions.empty()) {
            cout << "\n===== Converted Grammar =====\n";
            cout << "Productions:\n";
            for (const auto& prod : convertedProductions) {
                cout << "  " << prod.left << " -> ";
                if (prod.right == "e") cout << "ε";
                else cout << prod.right;
                cout << "\n";
            }
            cout << "=============================\n\n";
        }
    }
    
    void process() {
        cout << "Computing FIRST and FOLLOW sets...\n";
        computeFirst();
        computeFollow();
        displayFirstFollowSets();
        
        bool isLL1 = checkLL1Conflicts();
        
        if (!isLL1) {
            cout << "\nGrammar is NOT LL(1) - Applying transformations...\n";
            eliminateLeftRecursion();
            displayConvertedGrammar();
        }
    }
};

int main() {
    LL1Verifier verifier;
    string filename;
    
    cout << "================================\n";
    cout << "  LL(1) Verification Program\n";
    cout << "================================\n\n";
    
    cout << "Enter grammar file name: ";
    cin >> filename;
    
    verifier.readGrammarFromFile(filename);
    verifier.displayGrammar();
    verifier.process();
    
    return 0;
}