#include<iostream>
#include<fstream>
#include<cstring>
#include<string>
#include<vector>
using namespace std;

const char* get_reg(){
    static bool toggle = false;
    toggle = !toggle;
    return toggle ? "R0" : "R1";
}

void generate_code(string line){
    char lhs[20], op1[20], op2[20], op;
    
    if(sscanf(line.c_str(),"%s = %s %c %s",lhs,op1,&op,op2)==4){
        const char *r=get_reg();
        printf("MOV %s, %s\n",r,op1);
        switch(op){
            case '+': printf("ADD %s, %s\n",r,op2); break;
            case '-': printf("SUB %s, %s\n",r,op2); break;
            case '*': printf("MUL %s, %s\n",r,op2); break;
            case '/': printf("DIV %s, %s\n",r,op2); break;
        }
        printf("MOV %s, %s\n",lhs,r);
    }
    else if(sscanf(line.c_str(),"%s = %s",lhs,op1)==2){
        printf("MOV %s, %s\n",lhs,op1);
    }
}

int main(){
    string fn;
    cout<<"Enter TAC filename: ";
    cin>>fn;
    
    ifstream fin(fn);
    vector<string> tac;
    string line;
    
    while(getline(fin,line)){
        if(line.length()>0) tac.push_back(line);
    }
    fin.close();
    
    cout<<"\n--- Input Three Address Code (TAC) ---\n\n";
    for(int i=0;i<tac.size();i++)
        cout<<tac[i]<<"\n";
    
    cout<<"\n--- Generated Assembly Code ---\n\n";
    for(int i=0;i<tac.size();i++){
        generate_code(tac[i]);
        cout<<"\n";
    }
    
    return 0;
}