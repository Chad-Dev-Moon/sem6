#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<algorithm>
#include<iomanip>
using namespace std;

string trim(string s){
    auto b=s.find_first_not_of(" \t\r\n");
    if(b==string::npos) return "";
    auto e=s.find_last_not_of(" \t\r\n");
    return s.substr(b,e-b+1);
}

bool isJump(string s){ return s.find("goto")!=string::npos; }
bool isReturn(string s){ return s.find("return")==0; }
bool isLabel(string s){ return !s.empty()&&s.back()==':'; }
bool isCondJump(string s){ return s.find("if ")== 0&&isJump(s); }

string jumpTarget(string s){
    auto p=s.find("goto");
    string rest=s.substr(p+4);
    istringstream ss(rest); string t; ss>>t; return t;
}

string labelName(string s){ return s.substr(0,s.size()-1); }

struct Block {
    int id, start, end;
    vector<int> succ, pred;
};

class FlowGraph {
public:
    vector<string> code;
    vector<Block> blocks;
    map<string,int> label_map;
    vector<set<int>> dom;

    void load(string fn){
        ifstream fin(fn);
        string line; int idx=0;
        while(getline(fin,line)){
            line=trim(line);
            if(line.empty()) continue;
            code.push_back(line);
            if(isLabel(line)) label_map[labelName(line)]=idx;
            idx++;
        }
    }

    void findLeaders(){
        int n=code.size();
        vector<bool> leader(n,false);
        leader[0]=true;
        for(int i=0;i<n;i++){
            if(isJump(code[i])){
                if(i+1<n) leader[i+1]=true;
                string tgt=jumpTarget(code[i]);
                if(label_map.find(tgt)!=label_map.end()) 
                    leader[label_map[tgt]]=true;
            }
            if(isReturn(code[i])) if(i+1<n) leader[i+1]=true;
        }
        
        int id=1;
        for(int i=0;i<n;i++){
            if(!leader[i]) continue;
            int j=i+1; while(j<n&&!leader[j]) j++;
            blocks.push_back({id++,i,j-1,{},{}});
        }
    }

    int lineToBlock(int li){
        for(int i=0;i<blocks.size();i++)
            if(li>=blocks[i].start&&li<=blocks[i].end) return i;
        return -1;
    }

    void addEdge(int from, int to){
        if(find(blocks[from].succ.begin(),blocks[from].succ.end(),to)==blocks[from].succ.end()){
            blocks[from].succ.push_back(to);
            blocks[to].pred.push_back(from);
        }
    }

    void buildEdges(){
        int nb=blocks.size();
        for(int b=0;b<nb;b++){
            int last=blocks[b].end;
            string ins=code[last];
            if(isReturn(ins)) continue;
            if(isJump(ins)){
                string tgt=jumpTarget(ins);
                if(label_map.find(tgt)!=label_map.end()){
                    int tb=lineToBlock(label_map[tgt]);
                    addEdge(b,tb);
                }
                if(isCondJump(ins)&&b+1<nb) addEdge(b,b+1);
            } else {
                if(b+1<nb) addEdge(b,b+1);
            }
        }
    }

    void computeDominators(){
        int n=blocks.size();
        dom.resize(n);
        set<int> all;
        for(int i=0;i<n;i++) all.insert(i);
        
        for(int i=0;i<n;i++) dom[i]=all;
        dom[0]={0};

        bool changed=true;
        while(changed){
            changed=false;
            for(int i=1;i<n;i++){
                set<int> nd=all;
                for(int p:blocks[i].pred){
                    set<int> tmp;
                    set_intersection(nd.begin(),nd.end(),
                                     dom[p].begin(),dom[p].end(),
                                     inserter(tmp,tmp.begin()));
                    nd=tmp;
                }
                nd.insert(i);
                if(nd!=dom[i]){ dom[i]=nd; changed=true; }
            }
        }
    }

    int immDom(int n){
        if(n==0) return -1;
        vector<int> strict;
        for(int d:dom[n]) if(d!=n) strict.push_back(d);
        
        for(int cand:strict){
            bool ok=true;
            for(int other:strict){
                if(other==cand) continue;
                if(dom[other].find(cand)==dom[other].end()){ok=false;break;}
            }
            if(ok) return cand;
        }
        return -1;
    }

    void build(){
        findLeaders();
        buildEdges();
        computeDominators();
    }

    void print(){
        cout<<"\n=== TAC Code ===\n";
        for(int i=0;i<code.size();i++)
            cout<<"["<<i+1<<"] "<<code[i]<<"\n";

        cout<<"\n=== Basic Blocks ===\n";
        for(auto &b:blocks){
            cout<<"\nB"<<b.id<<" (lines "<<b.start+1<<"-"<<b.end+1<<")\n";
            for(int k=b.start;k<=b.end;k++)
                cout<<"  "<<code[k]<<"\n";
        }

        cout<<"\n=== Flow Graph Edges ===\n";
        for(auto &b:blocks){
            cout<<"B"<<b.id<<" -> ";
            if(b.succ.empty()) cout<<"(none)\n";
            else {
                for(int i=0;i<b.succ.size();i++){
                    if(i) cout<<", ";
                    cout<<"B"<<blocks[b.succ[i]].id;
                }
                cout<<"\n";
            }
        }

        cout<<"\n=== Dominator Sets ===\n";
        for(int i=0;i<blocks.size();i++){
            cout<<"DOM(B"<<blocks[i].id<<") = { ";
            for(int d:dom[i]) cout<<"B"<<blocks[d].id<<" ";
            cout<<"}\n";
        }

        cout<<"\n=== Immediate Dominators ===\n";
        for(int i=0;i<blocks.size();i++){
            int id=immDom(i);
            if(id==-1) cout<<"IDOM(B"<<blocks[i].id<<") = none\n";
            else cout<<"IDOM(B"<<blocks[i].id<<") = B"<<blocks[id].id<<"\n";
        }
    }
};

int main(){
    string fn;
    cout<<"Enter TAC filename: ";
    cin>>fn;
    
    FlowGraph fg;
    fg.load(fn);
    fg.build();
    fg.print();

    return 0;
}