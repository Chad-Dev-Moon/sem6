#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#define MAX_NT 30
#define MAX_PRODS 40
#define MAX_SYM 20
#define MAX_SYM_LEN 32
#define MAX_TERM 60
#define MAX_SET 40

typedef struct {
    char syms[MAX_SYM][MAX_SYM_LEN];
    int len;
} Prod;

typedef struct {
    char lhs[MAX_SYM_LEN];
    Prod prods[MAX_PRODS];
    int nprods;
} Rule;

typedef struct {
    char elems[MAX_SET][MAX_SYM_LEN];
    int size;
} Set;

Rule rules[MAX_NT];
int nrules;
char start[MAX_SYM_LEN];

char nts[MAX_NT][MAX_SYM_LEN];
int nnt;

char terms[MAX_TERM][MAX_SYM_LEN];
int nterm;

Set first[MAX_NT];
Set follow[MAX_NT];

int table[MAX_NT][MAX_TERM];

void trim(char *s) {
    char *p = s;
    while(*p == ' ' || *p == '\t') p++;
    memmove(s, p, strlen(p) + 1);
    int l = strlen(s);
    while(l > 0 && (s[l-1] == ' ' || s[l-1] == '\t' || s[l-1] == '\n' || s[l-1] == '\r'))
        s[--l] = '\0';
}

int isNt(const char *s) { return strlen(s) == 1 && isupper(s[0]); }
int isEps(const char *s) { return strcmp(s, "e") == 0 || strcmp(s, "eps") == 0; }

int findNt(const char *s) {
    for(int i = 0; i < nnt; i++) if(strcmp(nts[i], s) == 0) return i;
    return -1;
}

int findTerm(const char *s) {
    for(int i = 0; i < nterm; i++) if(strcmp(terms[i], s) == 0) return i;
    return -1;
}

int findRule(const char *s) {
    for(int i = 0; i < nrules; i++) if(strcmp(rules[i].lhs, s) == 0) return i;
    return -1;
}

void regNt(const char *s) {
    if(findNt(s) == -1) {
        strcpy(nts[nnt], s);
        first[nnt].size = 0;
        follow[nnt].size = 0;
        nnt++;
    }
}

void regTerm(const char *s) {
    if(!isNt(s) && !isEps(s) && findTerm(s) == -1) {
        strcpy(terms[nterm++], s);
    }
}

int setAdd(Set *S, const char *v) {
    for(int i = 0; i < S->size; i++) if(strcmp(S->elems[i], v) == 0) return 0;
    strcpy(S->elems[S->size++], v);
    return 1;
}

int setHas(const Set *S, const char *v) {
    for(int i = 0; i < S->size; i++) if(strcmp(S->elems[i], v) == 0) return 1;
    return 0;
}

void tokenise(const char *src, Prod *p) {
    p->len = 0;
    char buf[512];
    strcpy(buf, src);
    if(strchr(buf, ' ') || strchr(buf, '\t')) {
        char *tok = strtok(buf, " \t");
        while(tok && p->len < MAX_SYM) {
            strcpy(p->syms[p->len++], tok);
            tok = strtok(NULL, " \t");
        }
    } else {
        for(int i = 0; buf[i] && p->len < MAX_SYM; i++) {
            p->syms[p->len][0] = buf[i];
            p->syms[p->len][1] = '\0';
            p->len++;
        }
    }
}

void loadGrammar(const char *fn) {
    FILE *fp = fopen(fn, "r");
    if(!fp) { printf("Cannot open %s\n", fn); exit(1); }
    
    nrules = 0; nnt = 0; nterm = 0;
    char line[512];
    
    while(fgets(line, sizeof(line), fp)) {
        trim(line);
        if(!line[0]) continue;
        
        char *arrow = strstr(line, "->");
        if(!arrow) continue;
        
        char lhs[MAX_SYM_LEN];
        int ll = arrow - line;
        strncpy(lhs, line, ll);
        lhs[ll] = '\0';
        trim(lhs);
        
        int ri = findRule(lhs);
        if(ri == -1) {
            ri = nrules++;
            strcpy(rules[ri].lhs, lhs);
            rules[ri].nprods = 0;
        }
        regNt(lhs);
        
        char rhs[512];
        strcpy(rhs, arrow + 2);
        trim(rhs);
        
        char *alt = strtok(rhs, "|");
        while(alt) {
            char a[256];
            strcpy(a, alt);
            trim(a);
            if(strlen(a) > 0) {
                Prod *pr = &rules[ri].prods[rules[ri].nprods++];
                tokenise(a, pr);
                for(int k = 0; k < pr->len; k++) {
                    if(!isNt(pr->syms[k]) && !isEps(pr->syms[k]))
                        regTerm(pr->syms[k]);
                }
            }
            alt = strtok(NULL, "|");
        }
    }
    fclose(fp);
    
    if(nrules > 0) strcpy(start, rules[0].lhs);
    if(findTerm("$") == -1) strcpy(terms[nterm++], "$");
}

void printGrammar(const char *title) {
    printf("\n===== %s =====\n", title);
    for(int i = 0; i < nrules; i++) {
        printf("%s -> ", rules[i].lhs);
        for(int j = 0; j < rules[i].nprods; j++) {
            if(j) printf(" | ");
            for(int k = 0; k < rules[i].prods[j].len; k++) {
                if(k) printf(" ");
                printf("%s", isEps(rules[i].prods[j].syms[k]) ? "e" : rules[i].prods[j].syms[k]);
            }
        }
        printf("\n");
    }
    printf("Start: %s\n\n", start);
}

int firstOfSeq(const Prod *p, int from, Set *out);

void computeFirstNt(const char *nt) {
    int idx = findNt(nt);
    if(idx == -1) return;
    
    int ri = findRule(nt);
    if(ri == -1) return;
    
    for(int j = 0; j < rules[ri].nprods; j++) {
        int eps = firstOfSeq(&rules[ri].prods[j], 0, &first[idx]);
        if(eps) setAdd(&first[idx], "e");
    }
}

int firstOfSeq(const Prod *p, int from, Set *out) {
    if(from >= p->len) return 1;
    
    const char *sym = p->syms[from];
    if(isEps(sym)) { setAdd(out, "e"); return 1; }
    if(!isNt(sym)) { setAdd(out, sym); return 0; }
    
    computeFirstNt(sym);
    int idx = findNt(sym);
    int hasEps = 0;
    for(int i = 0; i < first[idx].size; i++) {
        if(isEps(first[idx].elems[i])) hasEps = 1;
        else setAdd(out, first[idx].elems[i]);
    }
    if(hasEps) return firstOfSeq(p, from + 1, out);
    return 0;
}

void computeAllFirst() {
    int changed = 1;
    while(changed) {
        changed = 0;
        for(int i = 0; i < nnt; i++) {
            int old = first[i].size;
            computeFirstNt(nts[i]);
            if(first[i].size != old) changed = 1;
        }
    }
}

void computeAllFollow() {
    int si = findNt(start);
    setAdd(&follow[si], "$");
    
    int changed = 1;
    while(changed) {
        changed = 0;
        for(int i = 0; i < nrules; i++) {
            int Bi = findNt(rules[i].lhs);
            for(int j = 0; j < rules[i].nprods; j++) {
                const Prod *pr = &rules[i].prods[j];
                for(int k = 0; k < pr->len; k++) {
                    if(!isNt(pr->syms[k])) continue;
                    int Ai = findNt(pr->syms[k]);
                    if(Ai == -1) continue;
                    
                    Set bf;
                    bf.size = 0;
                    int eps = firstOfSeq(pr, k + 1, &bf);
                    for(int m = 0; m < bf.size; m++) {
                        if(!isEps(bf.elems[m])) {
                            if(setAdd(&follow[Ai], bf.elems[m])) changed = 1;
                        }
                    }
                    if(eps) {
                        for(int m = 0; m < follow[Bi].size; m++) {
                            if(setAdd(&follow[Ai], follow[Bi].elems[m])) changed = 1;
                        }
                    }
                }
            }
        }
    }
}

void buildTable() {
    for(int i = 0; i < nnt; i++) 
        for(int j = 0; j < nterm; j++) 
            table[i][j] = -1;
    
    for(int i = 0; i < nrules; i++) {
        int Ai = findNt(rules[i].lhs);
        for(int j = 0; j < rules[i].nprods; j++) {
            Set ff;
            ff.size = 0;
            int eps = firstOfSeq(&rules[i].prods[j], 0, &ff);
            if(eps) setAdd(&ff, "e");
            
            for(int m = 0; m < ff.size; m++) {
                if(isEps(ff.elems[m])) {
                    int fi = findNt(rules[i].lhs);
                    for(int n = 0; n < follow[fi].size; n++) {
                        int ti = findTerm(follow[fi].elems[n]);
                        if(ti == -1) continue;
                        if(table[Ai][ti] == -1) table[Ai][ti] = j;
                        else if(table[Ai][ti] != j) table[Ai][ti] = -2;
                    }
                } else {
                    int ti = findTerm(ff.elems[m]);
                    if(ti == -1) continue;
                    if(table[Ai][ti] == -1) table[Ai][ti] = j;
                    else if(table[Ai][ti] != j) table[Ai][ti] = -2;
                }
            }
        }
    }
}

int checkLL1() {
    for(int i = 0; i < nnt; i++) 
        for(int j = 0; j < nterm; j++) 
            if(table[i][j] == -2) return 0;
    return 1;
}

int hasLeftRecursion() {
    for(int i = 0; i < nrules; i++) {
        for(int j = 0; j < rules[i].nprods; j++) {
            if(rules[i].prods[j].len > 0 && 
               strcmp(rules[i].prods[j].syms[0], rules[i].lhs) == 0)
                return 1;
        }
    }
    return 0;
}

void eliminateLeftRecursion() {
    printf("Eliminating left recursion...\n");
    int oldNrules = nrules;
    
    for(int i = 0; i < oldNrules; i++) {
        char *A = rules[i].lhs;
        Prod rec[MAX_PRODS], norec[MAX_PRODS];
        int nrec = 0, nnorec = 0;
        
        for(int j = 0; j < rules[i].nprods; j++) {
            Prod *pr = &rules[i].prods[j];
            if(pr->len > 0 && strcmp(pr->syms[0], A) == 0) {
                rec[nrec].len = 0;
                for(int k = 1; k < pr->len; k++) 
                    strcpy(rec[nrec].syms[rec[nrec].len++], pr->syms[k]);
                if(rec[nrec].len == 0) { 
                    strcpy(rec[nrec].syms[0], "e"); 
                    rec[nrec].len = 1; 
                }
                nrec++;
            } else {
                norec[nnorec++] = *pr;
            }
        }
        
        if(nrec == 0) continue;
        
        char Ap[2] = {'X', '\0'};
        printf("  Introducing new NT %s for %s\n", Ap, A);
        
        rules[i].nprods = 0;
        for(int k = 0; k < nnorec; k++) {
            Prod *np = &rules[i].prods[rules[i].nprods];
            *np = norec[k];
            strcpy(np->syms[np->len++], Ap);
            rules[i].nprods++;
        }
        
        int ni = nrules++;
        strcpy(rules[ni].lhs, Ap);
        rules[ni].nprods = 0;
        
        for(int k = 0; k < nrec; k++) {
            Prod *np = &rules[ni].prods[rules[ni].nprods];
            *np = rec[k];
            strcpy(np->syms[np->len++], Ap);
            rules[ni].nprods++;
        }
        
        Prod *ep = &rules[ni].prods[rules[ni].nprods++];
        ep->len = 1;
        strcpy(ep->syms[0], "e");
        
        regNt(Ap);
    }
}

int hasCommonPrefix() {
    for(int i = 0; i < nrules; i++) {
        for(int j = 0; j < rules[i].nprods - 1; j++) {
            for(int k = j + 1; k < rules[i].nprods; k++) {
                if(rules[i].prods[j].len > 0 && rules[i].prods[k].len > 0 &&
                   strcmp(rules[i].prods[j].syms[0], rules[i].prods[k].syms[0]) == 0)
                    return 1;
            }
        }
    }
    return 0;
}

void leftFactor() {
    printf("Performing left factoring...\n");
    
    for(int i = 0; i < nrules; i++) {
        for(int j = 0; j < rules[i].nprods; j++) {
            if(rules[i].prods[j].len == 0) continue;
            
            const char *first = rules[i].prods[j].syms[0];
            int grp[MAX_PRODS], ngrp = 0;
            
            for(int k = 0; k < rules[i].nprods; k++) {
                if(rules[i].prods[k].len > 0 && 
                   strcmp(rules[i].prods[k].syms[0], first) == 0)
                    grp[ngrp++] = k;
            }
            
            if(ngrp < 2) continue;
            
            char Ap[2] = {'Y', '\0'};
            printf("  Factoring on '%s' -> introducing %s\n", first, Ap);
            
            int ni = nrules++;
            strcpy(rules[ni].lhs, Ap);
            rules[ni].nprods = 0;
            
            for(int g = 0; g < ngrp; g++) {
                Prod *src = &rules[i].prods[grp[g]];
                Prod *dst = &rules[ni].prods[rules[ni].nprods++];
                dst->len = 0;
                for(int k = 1; k < src->len; k++) 
                    strcpy(dst->syms[dst->len++], src->syms[k]);
                if(dst->len == 0) { 
                    dst->len = 1; 
                    strcpy(dst->syms[0], "e"); 
                }
            }
            regNt(Ap);
            
            Prod newProds[MAX_PRODS];
            int nnp = 0;
            for(int k = 0; k < rules[i].nprods - 1; k++) {
                int inGrp = 0;
                for(int g = 0; g < ngrp; g++) 
                    if(grp[g] == k) { inGrp = 1; break; }
                if(!inGrp) newProds[nnp++] = rules[i].prods[k];
            }
            
            Prod *np = &newProds[nnp++];
            np->len = 1;
            strcpy(np->syms[0], first);
            strcpy(np->syms[1], Ap);
            np->len = 2;
            
            rules[i].nprods = nnp;
            for(int k = 0; k < nnp; k++) rules[i].prods[k] = newProds[k];
            return;
        }
    }
}

void recompute() {
    for(int i = 0; i < nnt; i++) { 
        first[i].size = 0; 
        follow[i].size = 0; 
    }
    computeAllFirst();
    computeAllFollow();
    buildTable();
}

int main() {
    printf("LL(1) Grammar Verifier & Transformer\n");
    printf("=====================================\n\n");
    
    char fn[256];
    printf("Enter grammar file: ");
    scanf("%s", fn);
    
    loadGrammar(fn);
    printGrammar("Original Grammar");
    
    printf("Computing FIRST and FOLLOW...\n");
    computeAllFirst();
    computeAllFollow();
    
    printf("Building LL(1) table...\n");
    buildTable();
    
    if(checkLL1()) {
        printf("\nRESULT: Grammar IS LL(1)!\n");
        return 0;
    }
    
    printf("\nRESULT: Grammar is NOT LL(1).\n");
    printf("Left recursion: %s\n", hasLeftRecursion() ? "YES" : "NO");
    printf("Common prefix: %s\n\n", hasCommonPrefix() ? "YES" : "NO");
    
    printf("Transforming...\n");
    if(hasLeftRecursion()) eliminateLeftRecursion();
    if(hasCommonPrefix()) leftFactor();
    
    printGrammar("Transformed Grammar");
    
    printf("Recomputing...\n");
    recompute();
    
    if(checkLL1()) {
        printf("RESULT: Transformed grammar IS LL(1)!\n");
    } else {
        printf("RESULT: Still NOT LL(1) (may need more passes)\n");
    }
    
    return 0;
}