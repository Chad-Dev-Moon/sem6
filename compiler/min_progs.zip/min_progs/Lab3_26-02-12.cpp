#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <queue>
#include <algorithm>
#include <sstream>

using namespace std;

class NFA {
public:
    set<string> states;
    set<char> alphabet;
    map<pair<string, char>, set<string>> transitions;
    string startState;
    set<string> finalStates;

    bool readFromFile(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "Error: Could not open file " << filename << endl;
            return false;
        }

        int numStates, numAlphabet, numTransitions, numFinalStates;

        // Read number of states
        file >> numStates;
        string state;
        for (int i = 0; i < numStates; i++) {
            file >> state;
            states.insert(state);
        }

        // Read alphabet (excluding epsilon)
        file >> numAlphabet;
        char symbol;
        for (int i = 0; i < numAlphabet; i++) {
            file >> symbol;
            if (symbol != 'e') {  // 'e' = epsilon
                alphabet.insert(symbol);
            }
        }

        // Read start state
        file >> startState;

        // Read final states
        file >> numFinalStates;
        for (int i = 0; i < numFinalStates; i++) {
            file >> state;
            finalStates.insert(state);
        }

        // Read transitions
        file >> numTransitions;
        string fromState, toState;
        char symbol;
        for (int i = 0; i < numTransitions; i++) {
            file >> fromState >> symbol >> toState;
            transitions[make_pair(fromState, symbol)].insert(toState);
        }

        file.close();
        return true;
    }

    void display() {
        cout << "\n========== NFA Definition ==========" << endl;

        cout << "States: { ";
        for (const auto& state : states) {
            cout << state << " ";
        }
        cout << "}" << endl;

        cout << "Alphabet: { ";
        for (char symbol : alphabet) {
            cout << symbol << " ";
        }
        cout << "}" << endl;

        cout << "Start State: " << startState << endl;

        cout << "Final States: { ";
        for (const auto& state : finalStates) {
            cout << state << " ";
        }
        cout << "}" << endl;

        cout << "\nNFA Transition Table:" << endl;
        cout << "State\t| ";
        for (char symbol : alphabet) {
            cout << symbol << "\t| ";
        }
        // Check for epsilon transitions
        bool hasEpsilon = false;
        for (const auto& trans : transitions) {
            if (trans.first.second == 'e') {
                hasEpsilon = true;
                break;
            }
        }
        if (hasEpsilon) {
            cout << "e\t| ";
        }
        cout << endl;
        cout << string(50, '-') << endl;

        for (const auto& state : states) {
            cout << state << "\t| ";
            for (char symbol : alphabet) {
                auto it = transitions.find(make_pair(state, symbol));
                if (it != transitions.end()) {
                    cout << "{ ";
                    for (const auto& s : it->second) {
                        cout << s << " ";
                    }
                    cout << "}\t| ";
                } else {
                    cout << "_\t| ";
                }
            }
            if (hasEpsilon) {
                auto it = transitions.find(make_pair(state, 'e'));
                if (it != transitions.end()) {
                    cout << "{ ";
                    for (const auto& s : it->second) {
                        cout << s << " ";
                    }
                    cout << "}\t| ";
                } else {
                    cout << "_\t| ";
                }
            }
            cout << endl;
        }
        cout << "=========================================\n" << endl;
    }

    // Compute epsilon closure of a set of states
    set<string> epsilonClosure(const set<string>& states) {
        set<string> closure = states;
        queue<string> q;

        for (const auto& state : states) {
            q.push(state);
        }

        while (!q.empty()) {
            string current = q.front();
            q.pop();

            auto it = transitions.find(make_pair(current, 'e'));
            if (it != transitions.end()) {
                for (const auto& state : it->second) {
                    if (closure.find(state) == closure.end()) {
                        closure.insert(state);
                        q.push(state);
                    }
                }
            }
        }

        return closure;
    }

    // Get move on symbol for a set of states
    set<string> move(const set<string>& states, char symbol) {
        set<string> result;

        for (const auto& state : states) {
            auto it = transitions.find(make_pair(state, symbol));
            if (it != transitions.end()) {
                result.insert(it->second.begin(), it->second.end());
            }
        }

        return result;
    }
};

class DFA {
public:
    set<set<string>> states;  // Each state is a set of NFA states
    set<char> alphabet;
    map<pair<set<string>, char>, set<string>> transitions;
    set<string> startState;
    set<set<string>> finalStates;

    // Map to give names to DFA states
    map<set<string>, string> stateNames;
    int stateCounter;

    DFA() : stateCounter(0) {}

    string getStateName(const set<string>& stateSet) {
        if (stateNames.find(stateSet) == stateNames.end()) {
            if (stateSet.empty()) {
                stateNames[stateSet] = "_";
            } else {
                stateNames[stateSet] = "q" + to_string(stateCounter++);
            }
        }
        return stateNames[stateSet];
    }

    string setToString(const set<string>& s) {
        if (s.empty()) return "_";
        string result = "{";
        bool first = true;
        for (const auto& elem : s) {
            if (!first) result += ",";
            result += elem;
            first = false;
        }
        result += "}";
        return result;
    }

    void display() {
        cout << "\n========== DFA Definition ==========" << endl;
        
        cout << "States: { ";
        for (const auto& state : states) {
            cout << getStateName(state) << " ";
        }
        cout << "}" << endl;

        cout << "Alphabet: { ";
        for (char symbol : alphabet) {
            cout << symbol << " ";
        }
        cout << "}" << endl;

        cout << "Start State: " << getStateName(startState) << endl;

        cout << "Final States: { ";
        for (const auto& state : finalStates) {
            cout << getStateName(state) << " ";
        }
        cout << "}" << endl;

        cout << "\nDFA Transition Table:" << endl;
        cout << "State\t\t| ";
        for (char symbol : alphabet) {
            cout << symbol << "\t\t| ";
        }
        cout << endl;
        cout << string(60, '-') << endl;

        for (const auto& state : states) {
            cout << getStateName(state) << "\t\t| ";
            for (char symbol : alphabet) {
                auto it = transitions.find(make_pair(state, symbol));
                if (it != transitions.end()) {
                    cout << getStateName(it->second) << "\t\t| ";
                } else {
                    cout << "_\t\t| ";
                }
            }
            cout << endl;
        }
        cout << "====================================\n" << endl;
    }

    void displayWithMapping() {
        cout << "\n========== DFA State Mapping ==========" << endl;
        cout << "DFA State\t-> NFA States" << endl;
        cout << string(50, '-') << endl;
        
        for (const auto& state : states) {
            cout << getStateName(state) << "\t\t-> " << setToString(state) << endl;
        }
        cout << "========================================\n" << endl;
    }

    void saveToFile(const string& filename) {
        ofstream file(filename);
        if (!file.is_open()) {
            cout << "Error: Could not create output file" << endl;
            return;
        }

        // Write number of states
        file << states.size() << endl;
        for (const auto& state : states) {
            file << getStateName(state) << " ";
        }
        file << endl;

        // Write alphabet
        file << alphabet.size() << endl;
        for (char symbol : alphabet) {
            file << symbol << " ";
        }
        file << endl;

        // Write start state
        file << getStateName(startState) << endl;

        // Write final states
        file << finalStates.size() << endl;
        for (const auto& state : finalStates) {
            file << getStateName(state) << " ";
        }
        file << endl;

        // Write transitions
        file << transitions.size() << endl;
        for (const auto& trans : transitions) {
            file << getStateName(trans.first.first) << " " 
                 << trans.first.second << " " 
                 << getStateName(trans.second) << endl;
        }

        file.close();
        cout << "DFA saved to file: " << filename << endl;
    }
};

class NFAtoDFAConverter {
private:
    NFA nfa;
    DFA dfa;

public:
    bool loadNFA(const string& filename) {
        return nfa.readFromFile(filename);
    }

    void displayNFA() {
        nfa.display();
    }

    void convert() {
        cout << "\n========== Converting NFA to DFA ==========" << endl;

        // Initialize DFA alphabet
        dfa.alphabet = nfa.alphabet;

        // Compute initial state (epsilon closure of NFA start state)
        set<string> initialSet;
        initialSet.insert(nfa.startState);
        dfa.startState = nfa.epsilonClosure(initialSet);
        
        cout << "Initial DFA state: " << dfa.setToString(dfa.startState) << endl;

        // Queue for unprocessed DFA states
        queue<set<string>> unmarked;
        unmarked.push(dfa.startState);
        dfa.states.insert(dfa.startState);

        // Check if start state is final
        for (const auto& state : dfa.startState) {
            if (nfa.finalStates.find(state) != nfa.finalStates.end()) {
                dfa.finalStates.insert(dfa.startState);
                break;
            }
        }

        int stepCount = 1;
        // Subset construction algorithm
        while (!unmarked.empty()) {
            set<string> current = unmarked.front();
            unmarked.pop();

            cout << "\nStep " << stepCount++ << ": Processing state " 
                 << dfa.setToString(current) << endl;

            for (char symbol : dfa.alphabet) {
                // Compute move and epsilon closure
                set<string> moveResult = nfa.move(current, symbol);
                set<string> newState = nfa.epsilonClosure(moveResult);

                cout << "  On '" << symbol << "': " << dfa.setToString(current) 
                     << " -> " << dfa.setToString(newState) << endl;

                // Add transition
                dfa.transitions[make_pair(current, symbol)] = newState;

                // If new state not seen before, add to unmarked
                if (dfa.states.find(newState) == dfa.states.end() && !newState.empty()) {
                    dfa.states.insert(newState);
                    unmarked.push(newState);

                    // Check if new state is final
                    for (const auto& state : newState) {
                        if (nfa.finalStates.find(state) != nfa.finalStates.end()) {
                            dfa.finalStates.insert(newState);
                            break;
                        }
                    }
                }
            }
        }

        cout << "\n========== Conversion Complete ==========" << endl;
        cout << "Number of DFA states: " << dfa.states.size() << endl;
        cout << "Number of final states: " << dfa.finalStates.size() << endl;
    }

    void displayDFA() {
        dfa.displayWithMapping();
        dfa.display();
    }

    void saveDFA(const string& filename) {
        dfa.saveToFile(filename);
    }
};

int main() {
    NFAtoDFAConverter converter;
    string filename;

    cout << "========================================" << endl;
    cout << "    NFA to DFA Conversion Program" << endl;
    cout << "========================================\n" << endl;

    cout << "Enter the NFA input file name: ";
    cin >> filename;

    if (!converter.loadNFA(filename)) {
        return 1;
    }

    converter.displayNFA();

    cout << "Press Enter to start conversion...";
    cin.ignore();
    cin.get();

    converter.convert();
    converter.displayDFA();

    string outputFile;
    cout << "\nEnter output file name for DFA (or 'skip' to skip): ";
    cin >> outputFile;

    if (outputFile != "skip") {
        converter.saveDFA(outputFile);
    }

    cout << "\nProgram completed successfully!" << endl;

    return 0;
}