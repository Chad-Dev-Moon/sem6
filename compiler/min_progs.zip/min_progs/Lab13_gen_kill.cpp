#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<algorithm>
using namespace std;

string trim(string s){
    auto b=s.find_first_not_of(" \t\r\n");
    if(b==string::npos) return "";
    auto e=s.find_last_not_of(" \t\r\n");
    return s.substr(b,e-b+1);
}

bool isJump(string s){ return s.find("goto")!=string::npos; }
bool isReturn(string s){ return s.find("return")==0; }
bool isLabel(string s){ return !s.empty()&&s.back()==':'; }
bool isParam(string s){ return s.find("param")==0; }
bool isCall(string s){ return s.find("call")==0; }

string jumpTarget(string s){
    auto p=s.find("goto");
    if(p==string::npos) return "";
    istringstream ss(s.substr(p+4)); string t; ss>>t; return t;
}

string labelName(string s){ return s.substr(0,s.size()-1); }

string parseLHS(string line){
    if(isLabel(line)||isJump(line)||isReturn(line)||isParam(line)||isCall(line))
        return "";
    
    for(size_t i=0;i<line.size();i++){
        if(line[i]=='='&&i>0
           &&line[i-1]!='!'&&line[i-1]!='<'&&line[i-1]!='>'&&line[i-1]!='='
           &&(i+1>=line.size()||line[i+1]!='='))
        {
            string lhs=trim(line.substr(0,i));
            auto br=lhs.find('[');
            if(br!=string::npos) lhs=trim(lhs.substr(0,br));
            return lhs;
        }
    }
    return "";
}

struct Def {
    int id, line, block;
    string var;
};

struct Block {
    int id, start, end;
};

class GenKillAnalyzer {
public:
    vector<string> code;
    map<string,int> label_map;
    vector<Block> blocks;
    vector<Def> defs;
    map<int,set<int>> gen_i, kill_i;
    map<int,set<int>> gen_b, kill_b;

    void load(string fn){
        ifstream fin(fn);
        string line; int idx=0;
        while(getline(fin,line)){
            line=trim(line);
            if(line.empty()) continue;
            code.push_back(line);
            if(isLabel(line)) label_map[labelName(line)]=idx;
            idx++;
        }
    }

    void findLeaders(){
        int n=code.size();
        vector<bool> leader(n,false);
        leader[0]=true;
        for(int i=0;i<n;i++){
            if(isJump(code[i])){
                if(i+1<n) leader[i+1]=true;
                if(label_map.find(jumpTarget(code[i]))!=label_map.end())
                    leader[label_map[jumpTarget(code[i])]]=true;
            }
            if(isReturn(code[i])&&i+1<n) leader[i+1]=true;
        }
        
        int id=1;
        for(int i=0;i<n;i++){
            if(!leader[i]) continue;
            int j=i+1; while(j<n&&!leader[j]) j++;
            blocks.push_back({id++,i,j-1});
        }
    }

    int lineToBlock(int li){
        for(int i=0;i<blocks.size();i++)
            if(li>=blocks[i].start&&li<=blocks[i].end) return i;
        return -1;
    }

    void buildDefs(){
        int id=1;
        for(int b=0;b<blocks.size();b++){
            for(int i=blocks[b].start;i<=blocks[b].end;i++){
                string v=parseLHS(code[i]);
                if(!v.empty())
                    defs.push_back({id++,i,b,v});
            }
        }
    }

    vector<int> defsOf(string var){
        vector<int> r;
        for(int i=0;i<defs.size();i++)
            if(defs[i].var==var) r.push_back(i);
        return r;
    }

    void computeInstrGenKill(){
        for(int di=0;di<defs.size();di++){
            int li=defs[di].line;
            gen_i[li].insert(di);
            for(int other:defsOf(defs[di].var))
                if(other!=di) kill_i[li].insert(other);
        }
    }

    void computeBlockGenKill(){
        for(int b=0;b<blocks.size();b++){
            set<int> running_gen;
            set<int> running_kill;

            for(int i=blocks[b].start;i<=blocks[b].end;i++){
                if(kill_i.count(i)){
                    for(int k:kill_i[i]) running_gen.erase(k);
                }
                if(gen_i.count(i)){
                    for(int g:gen_i[i]) running_gen.insert(g);
                }
                if(kill_i.count(i)){
                    for(int k:kill_i[i]) running_kill.insert(k);
                }
            }
            gen_b[b]=running_gen;
            kill_b[b]=running_kill;
        }
    }

    void run(){
        findLeaders();
        buildDefs();
        computeInstrGenKill();
        computeBlockGenKill();
    }

    string defSetStr(set<int> S){
        if(S.empty()) return "{ }";
        string r="{ ";
        bool f=true;
        for(int di:S){
            if(!f) r+=", ";
            r+="d"+to_string(defs[di].id)+"("+defs[di].var+")";
            f=false;
        }
        r+=" }";
        return r;
    }

    void print(){
        cout<<"\n=== TAC Code ===\n";
        for(int i=0;i<code.size();i++)
            cout<<"["<<i+1<<"] "<<code[i]<<"\n";

        cout<<"\n=== Definition Table ===\n";
        cout<<"Def | Variable | Block | Instruction\n";
        cout<<"----+----------+-------+-----------\n";
        for(auto &d:defs)
            cout<<"d"<<d.id<<" | "<<d.var<<" | B"<<d.block+1<<" | ["<<d.line+1<<"] "<<code[d.line]<<"\n";

        cout<<"\n=== Instruction-Level GEN & KILL ===\n";
        for(auto &bl:blocks){
            cout<<"\nBlock B"<<bl.id<<"\n";
            for(int i=bl.start;i<=bl.end;i++){
                set<int> gi=gen_i.count(i)?gen_i[i]:set<int>{};
                set<int> ki=kill_i.count(i)?kill_i[i]:set<int>{};
                cout<<"["<<i+1<<"] "<<code[i]<<"\n";
                cout<<"  GEN  = "<<defSetStr(gi)<<"\n";
                cout<<"  KILL = "<<defSetStr(ki)<<"\n";
            }
        }

        cout<<"\n=== Block-Level GEN & KILL ===\n";
        for(auto &bl:blocks){
            int b=bl.id-1;
            set<int> gb=gen_b.count(b)?gen_b[b]:set<int>{};
            set<int> kb=kill_b.count(b)?kill_b[b]:set<int>{};
            cout<<"\nBlock B"<<bl.id<<" (lines "<<bl.start+1<<"-"<<bl.end+1<<")\n";
            cout<<"GEN[B"<<bl.id<<"]  = "<<defSetStr(gb)<<"\n";
            cout<<"KILL[B"<<bl.id<<"] = "<<defSetStr(kb)<<"\n";
        }
        cout<<"\n";
    }
};

int main(){
    cout<<"=== GEN & KILL Set Evaluator ===\n";
    string fn;
    cout<<"Enter TAC filename: ";
    cin>>fn;

    GenKillAnalyzer analyzer;
    analyzer.load(fn);
    analyzer.run();
    analyzer.print();

    return 0;
}