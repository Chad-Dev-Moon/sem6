#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <vector>

using namespace std;

class MooreMachine {
private:
    set<string> states;
    set<char> inputAlphabet;
    set<char> outputAlphabet;
    // Transition: (currentState, inputSymbol) -> nextState
    map<pair<string, char>, string> transitions;
    // Output: state -> outputSymbol
    map<string, char> outputs;
    string startState;

public:
    // Read Moore Machine from file
    bool readFromFile(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "Error: Could not open file " << filename << endl;
            return false;
        }

        int numStates, numInputAlphabet, numOutputAlphabet, numTransitions;
        
        // Read number of states
        file >> numStates;
        string state;
        for (int i = 0; i < numStates; i++) {
            file >> state;
            states.insert(state);
        }

        // Read input alphabet
        file >> numInputAlphabet;
        char symbol;
        for (int i = 0; i < numInputAlphabet; i++) {
            file >> symbol;
            inputAlphabet.insert(symbol);
        }

        // Read output alphabet
        file >> numOutputAlphabet;
        for (int i = 0; i < numOutputAlphabet; i++) {
            file >> symbol;
            outputAlphabet.insert(symbol);
        }

        // Read start state
        file >> startState;

        // Read state outputs
        char output;
        for (int i = 0; i < numStates; i++) {
            file >> state >> output;
            outputs[state] = output;
        }

        // Read transitions
        file >> numTransitions;
        string fromState, toState;
        char inputSymbol;
        for (int i = 0; i < numTransitions; i++) {
            file >> fromState >> inputSymbol >> toState;
            transitions[make_pair(fromState, inputSymbol)] = toState;
        }

        file.close();
        return true;
    }

    // Process input string and generate output
    bool processString(const string& input, string& output) {
        string currentState = startState;
        output = "";

        // Output for initial state
        output += outputs[currentState];

        for (int i = 0; i < input.length(); i++) {
            char symbol = input[i];
            
            // Check if symbol is in input alphabet
            if (inputAlphabet.find(symbol) == inputAlphabet.end()) {
                cout << "Error: Input symbol '" << symbol << "' at position " 
                     << i << " is not in the input alphabet" << endl;
                return false;
            }

            // Get transition
            auto transition = transitions.find(make_pair(currentState, symbol));
            if (transition == transitions.end()) {
                cout << "Error: No valid transition from state '" << currentState 
                     << "' on input symbol '" << symbol << "' at position " << i << endl;
                return false;
            }

            // Update state
            currentState = transition->second;
            
            // Append output for new state
            output += outputs[currentState];
        }

        return true;
    }

    // Display Moore Machine information
    void display() {
        cout << "\n=== Moore Machine Information ===" << endl;
        
        cout << "States: ";
        for (const auto& state : states) {
            cout << state << " ";
        }
        cout << endl;

        cout << "Input Alphabet: ";
        for (char symbol : inputAlphabet) {
            cout << symbol << " ";
        }
        cout << endl;

        cout << "Output Alphabet: ";
        for (char symbol : outputAlphabet) {
            cout << symbol << " ";
        }
        cout << endl;

        cout << "Start State: " << startState << endl;

        cout << "\nState Outputs:" << endl;
        cout << "State | Output" << endl;
        cout << "--------------" << endl;
        for (const auto& output : outputs) {
            cout << "  " << output.first << "   |   " << output.second << endl;
        }

        cout << "\nTransition Table:" << endl;
        cout << "Current State | Input | Next State" << endl;
        cout << "--------------------------------------" << endl;
        for (const auto& transition : transitions) {
            cout << "     " << transition.first.first << "      |   " 
                 << transition.first.second << "   |     " 
                 << transition.second << endl;
        }
        cout << "========================================\n" << endl;
    }
};

int main() {
    MooreMachine moore;
    string filename;

    cout << "Enter the Moore Machine file name: ";
    cin >> filename;

    if (!moore.readFromFile(filename)) {
        return 1;
    }

    moore.display();

    string input;
    cout << "Enter an input string (or 'quit' to exit): ";
    cin >> input;

    while (input != "quit") {
        string output;
        if (moore.processString(input, output)) {
            cout << "\nInput:  " << input << endl;
            cout << "Output: " << output << endl;
        } 
        else {
            cout << "Processing failed due to error above." << endl;
        }

        cout << "\nEnter an input string (or 'quit' to exit): ";
        cin >> input;
    }

    cout << "Exiting Program !" << endl;
    return 0;
}