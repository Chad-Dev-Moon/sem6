#include<bits/stdc++.h>
using namespace std;

vector<string> code;
map<string,int> labelLine;

struct Block { int id, start, end; vector<int> succ, pred; };
vector<Block> blocks;
vector<int> is_leader;

struct BackEdge { int tail, head; };
struct NaturalLoop { BackEdge be; set<int> members; };

vector<set<int>> dom;
vector<BackEdge> back_edges;
vector<NaturalLoop> loops;

string trim(string s){
    int i=0,j=s.size()-1;
    while(i<=j&&isspace(s[i])) i++;
    while(j>=i&&isspace(s[j])) j--;
    return (i<=j)?s.substr(i,j-i+1):"";
}

bool is_jump(string s){ return s.find("goto")!=string::npos; }
bool is_return(string s){ return s.find("return")==0; }
bool is_label(string s){ return !s.empty()&&s.back()==':'; }
bool is_cond_jump(string s){ return s.find("if ")==0&&is_jump(s); }

string get_target(string s){
    auto pos=s.find("goto");
    if(pos==string::npos) return "";
    pos+=4;
    while(pos<s.size()&&isspace(s[pos])) pos++;
    string t="";
    while(pos<s.size()&&!isspace(s[pos])) t+=s[pos++];
    return t;
}

int line_to_block(int li){
    for(int i=0;i<blocks.size();i++)
        if(li>=blocks[i].start&&li<=blocks[i].end) return i;
    return -1;
}

void load_tac(string fn){
    ifstream f(fn);
    string line;
    while(getline(f,line)){
        line=trim(line);
        if(line.empty()) continue;
        code.push_back(line);
        if(is_label(line)){
            string l=line.substr(0,line.size()-1);
            labelLine[l]=code.size()-1;
        }
    }
}

void find_leaders(){
    is_leader.assign(code.size(),0);
    is_leader[0]=1;
    for(int i=0;i<code.size();i++){
        if(is_jump(code[i])){
            if(i+1<code.size()) is_leader[i+1]=1;
            string t=get_target(code[i]);
            if(labelLine.count(t)) is_leader[labelLine[t]]=1;
        }
    }
}

void build_blocks(){
    int id=1;
    for(int i=0;i<code.size();i++){
        if(!is_leader[i]) continue;
        int j=i+1;
        while(j<code.size()&&!is_leader[j]) j++;
        blocks.push_back({id++,i,j-1,{},{}});
    }
}

void build_flow_graph(){
    int n=blocks.size();
    for(int b=0;b<n;b++){
        string ins=code[blocks[b].end];
        if(is_return(ins)) continue;

        if(is_jump(ins)){
            string t=get_target(ins);
            if(labelLine.count(t)){
                int tb=line_to_block(labelLine[t]);
                if(tb!=-1){
                    blocks[b].succ.push_back(tb);
                    blocks[tb].pred.push_back(b);
                }
            }
            if(is_cond_jump(ins)&&b+1<n){
                blocks[b].succ.push_back(b+1);
                blocks[b+1].pred.push_back(b);
            }
        } else if(b+1<n){
            blocks[b].succ.push_back(b+1);
            blocks[b+1].pred.push_back(b);
        }
    }
}

void compute_dominators(){
    int n=blocks.size();
    dom.resize(n);
    set<int> all;
    for(int i=0;i<n;i++) all.insert(i);
    for(int i=0;i<n;i++) dom[i]=all;
    dom[0]={0};

    bool changed=true;
    while(changed){
        changed=false;
        for(int i=1;i<n;i++){
            set<int> nd=all;
            for(int p:blocks[i].pred){
                set<int> tmp;
                set_intersection(nd.begin(),nd.end(),
                                 dom[p].begin(),dom[p].end(),
                                 inserter(tmp,tmp.begin()));
                nd=tmp;
            }
            nd.insert(i);
            if(nd!=dom[i]){ dom[i]=nd; changed=true; }
        }
    }
}

bool dominates(int a, int b){
    return dom[b].count(a)>0;
}

void find_back_edges(){
    for(int n=0;n<blocks.size();n++)
        for(int h:blocks[n].succ)
            if(dominates(h,n))
                back_edges.push_back({n,h});
}

set<int> natural_loop(int n, int h){
    set<int> loop_set;
    loop_set.insert(h);
    if(n==h) return loop_set;

    loop_set.insert(n);
    queue<int> q;
    q.push(n);

    while(!q.empty()){
        int m=q.front(); q.pop();
        for(int p:blocks[m].pred){
            if(!loop_set.count(p)){
                loop_set.insert(p);
                q.push(p);
            }
        }
    }
    return loop_set;
}

void build_natural_loops(){
    for(auto &be:back_edges)
        loops.push_back({be, natural_loop(be.tail, be.head)});
}

int main(){
    string fn;
    cout<<"Enter TAC file: ";
    cin>>fn;

    load_tac(fn);
    find_leaders();
    build_blocks();
    build_flow_graph();
    compute_dominators();
    find_back_edges();
    build_natural_loops();

    cout<<"\n=== TAC Code ===\n";
    for(int i=0;i<code.size();i++)
        cout<<"["<<i+1<<"] "<<code[i]<<"\n";

    cout<<"\n=== Basic Blocks ===\n";
    for(auto &b:blocks){
        cout<<"B"<<b.id<<" (lines "<<b.start+1<<"-"<<b.end+1<<"): ";
        for(int k=b.start;k<=b.end;k++){
            if(k>b.start) cout<<" | ";
            cout<<code[k];
        }
        cout<<"\n";
    }

    cout<<"\n=== Flow Graph ===\n";
    for(auto &b:blocks){
        cout<<"B"<<b.id<<" --> ";
        if(b.succ.empty()) cout<<"(none)";
        else {
            for(int i=0;i<b.succ.size();i++){
                if(i) cout<<", ";
                cout<<"B"<<blocks[b.succ[i]].id;
            }
        }
        cout<<"\n";
    }

    cout<<"\n=== Dominator Sets ===\n";
    for(int i=0;i<blocks.size();i++){
        cout<<"DOM(B"<<blocks[i].id<<") = { ";
        for(int d:dom[i]) cout<<"B"<<blocks[d].id<<" ";
        cout<<"}\n";
    }

    cout<<"\n=== Back Edges ===\n";
    if(back_edges.empty()) cout<<"(none found)\n";
    else {
        for(int i=0;i<back_edges.size();i++)
            cout<<"Back Edge "<<(i+1)<<": B"<<(back_edges[i].tail+1)
                <<" --> B"<<(back_edges[i].head+1)<<"\n";
    }

    cout<<"\n=== Natural Loops ===\n";
    if(loops.empty()){
        cout<<"No natural loops found.\n";
    } else {
        for(int i=0;i<loops.size();i++){
            cout<<"\nLoop "<<(i+1)<<"\n";
            cout<<"Back Edge: B"<<(loops[i].be.tail+1)
                <<" --> B"<<(loops[i].be.head+1)<<"\n";
            cout<<"Loop Header: B"<<(loops[i].be.head+1)
                <<" ("<<code[blocks[loops[i].be.head].start]<<")\n";
            cout<<"Members: { ";
            for(int m:loops[i].members) cout<<"B"<<(m+1)<<" ";
            cout<<"}\n";
            cout<<"Instructions:\n";
            for(int m:loops[i].members){
                for(int k=blocks[m].start;k<=blocks[m].end;k++)
                    cout<<"  ["<<(k+1)<<"] "<<code[k]<<"\n";
            }
        }
    }

    cout<<"\n=== Summary ===\n";
    cout<<"Total back edges: "<<back_edges.size()<<"\n";
    cout<<"Total loops: "<<loops.size()<<"\n\n";

    return 0;
}