#include<bits/stdc++.h>
using namespace std;

vector<string> code;
unordered_map<string,int> labelLine;

struct Block { int start, end; };
vector<Block> blocks;
vector<int> is_leader;
vector<vector<int>> succ, pred;

struct Def { int line, block; string var; };
vector<Def> defs;

vector<vector<int>> gen_b, kill_b, in_b, out_b;

string trim(string s){
    int i=0,j=s.size()-1;
    while(i<=j && isspace(s[i])) i++;
    while(j>=i && isspace(s[j])) j--;
    return (i<=j)? s.substr(i,j-i+1):"";
}

bool is_jump(string s){ return s.find("goto")!=string::npos; }
bool is_return(string s){ return s.find("return")==0; }
bool is_label(string s){ return !s.empty()&&s.back()==':'; }
bool is_cond_jump(string s){ return s.find("if ")==0&&is_jump(s); }

string get_target(string s){
    auto pos=s.find("goto");
    if(pos==string::npos) return "";
    pos+=4;
    while(pos<s.size()&&isspace(s[pos])) pos++;
    string t="";
    while(pos<s.size()&&!isspace(s[pos])) t+=s[pos++];
    return t;
}

int line_to_block(int line){
    for(int i=0;i<blocks.size();i++)
        if(line>=blocks[i].start&&line<=blocks[i].end) return i;
    return -1;
}

string parse_lhs(string line){
    if(is_label(line)||is_jump(line)||is_return(line)) return "";
    auto pos=line.find('=');
    if(pos==string::npos) return "";
    return trim(line.substr(0,pos));
}

void load_tac(string fn){
    ifstream f(fn);
    string line;
    while(getline(f,line)){
        line=trim(line);
        if(line.empty()) continue;
        code.push_back(line);
        if(is_label(line)){
            string l=line.substr(0,line.size()-1);
            labelLine[l]=code.size()-1;
        }
    }
}

void find_leaders(){
    is_leader.assign(code.size(),0);
    is_leader[0]=1;
    for(int i=0;i<code.size();i++){
        if(is_jump(code[i])){
            if(i+1<code.size()) is_leader[i+1]=1;
            string t=get_target(code[i]);
            if(labelLine.count(t)) is_leader[labelLine[t]]=1;
        }
    }
}

void build_blocks(){
    for(int i=0;i<code.size();i++){
        if(!is_leader[i]) continue;
        int j=i+1;
        while(j<code.size()&&!is_leader[j]) j++;
        blocks.push_back({i,j-1});
    }
}

void build_flow_graph(){
    int n=blocks.size();
    succ.assign(n,vector<int>());
    pred.assign(n,vector<int>());

    for(int b=0;b<n;b++){
        string ins=code[blocks[b].end];
        if(is_return(ins)) continue;

        if(is_jump(ins)){
            string t=get_target(ins);
            if(labelLine.count(t)){
                int tb=line_to_block(labelLine[t]);
                succ[b].push_back(tb);
                pred[tb].push_back(b);
            }
            if(is_cond_jump(ins)&&b+1<n){
                succ[b].push_back(b+1);
                pred[b+1].push_back(b);
            }
        }
        else if(b+1<n){
            succ[b].push_back(b+1);
            pred[b+1].push_back(b);
        }
    }
}

void build_defs(){
    for(int b=0;b<blocks.size();b++){
        for(int i=blocks[b].start;i<=blocks[b].end;i++){
            string var=parse_lhs(code[i]);
            if(!var.empty()) defs.push_back({i,b,var});
        }
    }
}

void compute_gen_kill(){
    int B=blocks.size();
    gen_b.assign(B,vector<int>());
    kill_b.assign(B,vector<int>());

    for(int b=0;b<B;b++){
        vector<int> cur;
        for(int i=blocks[b].start;i<=blocks[b].end;i++){
            string var=parse_lhs(code[i]);
            if(var.empty()) continue;

            int di=-1;
            for(int k=0;k<defs.size();k++)
                if(defs[k].line==i) di=k;

            vector<int> newcur;
            for(int x:cur)
                if(defs[x].var!=var) newcur.push_back(x);

            for(int k=0;k<defs.size();k++)
                if(k!=di&&defs[k].var==var) kill_b[b].push_back(k);

            newcur.push_back(di);
            cur=newcur;
        }
        gen_b[b]=cur;
    }
}

void compute_in_out(){
    int B=blocks.size();
    in_b.assign(B,vector<int>());
    out_b.assign(B,vector<int>());

    bool changed=true;
    while(changed){
        changed=false;
        for(int b=0;b<B;b++){
            set<int> inSet;
            for(int p:pred[b])
                for(int x:out_b[p]) inSet.insert(x);

            vector<int> new_in(inSet.begin(),inSet.end());
            in_b[b]=new_in;

            set<int> outSet;
            for(int x:new_in)
                if(find(kill_b[b].begin(),kill_b[b].end(),x)==kill_b[b].end())
                    outSet.insert(x);

            for(int x:gen_b[b]) outSet.insert(x);

            vector<int> new_out(outSet.begin(),outSet.end());
            if(new_out!=out_b[b]){
                out_b[b]=new_out;
                changed=true;
            }
        }
    }
}

void print_set(vector<int> s){
    if(s.empty()){ cout<<"{ }"; return; }
    cout<<"{ ";
    for(int i=0;i<s.size();i++){
        cout<<"d"<<s[i]+1;
        if(i!=s.size()-1) cout<<", ";
    }
    cout<<" }";
}

int main(){
    string fn;
    cout<<"Enter TAC file: ";
    cin>>fn;

    load_tac(fn);
    find_leaders();
    build_blocks();
    build_flow_graph();
    build_defs();
    compute_gen_kill();
    compute_in_out();

    cout<<"\n=== TAC Code ===\n";
    for(int i=0;i<code.size();i++)
        cout<<"["<<i+1<<"] "<<code[i]<<"\n";

    cout<<"\n=== Basic Blocks ===\n";
    for(int i=0;i<blocks.size();i++)
        cout<<"B"<<i+1<<": lines "<<blocks[i].start+1<<"-"<<blocks[i].end+1<<"\n";

    cout<<"\n=== Definition Table ===\n";
    for(int i=0;i<defs.size();i++)
        cout<<"d"<<i+1<<": var="<<defs[i].var<<" at line "<<defs[i].line+1<<" (B"<<defs[i].block+1<<")\n";

    cout<<"\n=== GEN & KILL Sets ===\n";
    for(int i=0;i<blocks.size();i++){
        cout<<"B"<<i+1<<"\n";
        cout<<"GEN  = "; print_set(gen_b[i]); cout<<"\n";
        cout<<"KILL = "; print_set(kill_b[i]); cout<<"\n\n";
    }

    cout<<"\n=== IN & OUT Sets ===\n";
    for(int i=0;i<blocks.size();i++){
        cout<<"B"<<i+1<<"\n";
        cout<<"IN  = "; print_set(in_b[i]); cout<<"\n";
        cout<<"OUT = "; print_set(out_b[i]); cout<<"\n\n";
    }

    return 0;
}