#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<vector>
#include<map>
#include<cctype>
using namespace std;

struct CFG {
    map<char, vector<string>> rules;
    char start;
    
    void readFile(string filename) {
        ifstream f(filename);
        string line;
        bool first = true;
        
        while(getline(f, line)) {
            if(line.empty()) continue;
            
            size_t pos = line.find("->");
            if(pos == string::npos) continue;
            
            char lhs = line[0];
            if(first) {
                start = lhs;
                first = false;
            }
            
            string rhs = line.substr(pos + 2);
            
            stringstream ss(rhs);
            string prod;
            while(getline(ss, prod, '|')) {
                string trimmed = "";
                for(char c : prod) {
                    if(c != ' ' && c != '\t') trimmed += c;
                }
                if(!trimmed.empty()) {
                    rules[lhs].push_back(trimmed);
                }
            }
        }
        f.close();
    }
    
    void display() {
        cout << "\nGrammar Rules:" << endl;
        for(auto& p : rules) {
            cout << p.first << " -> ";
            for(int i = 0; i < p.second.size(); i++) {
                if(i > 0) cout << " | ";
                cout << p.second[i];
            }
            cout << endl;
        }
        cout << "Start: " << start << endl;
    }
};

class Parser {
private:
    CFG& cfg;
    string input;
    
public:
    Parser(CFG& g) : cfg(g) {}
    
    bool accepts(string str) {
        input = str;
        if(input.empty()) {
            return canDerive(cfg.start, "");
        }
        return canDerive(cfg.start, input);
    }
    
private:
    bool canDerive(char nonterm, string remaining) {
        if(cfg.rules.find(nonterm) == cfg.rules.end()) {
            return false;
        }
        
        for(string prod : cfg.rules[nonterm]) {
            if(tryProduction(prod, remaining)) {
                return true;
            }
        }
        return false;
    }
    
    bool tryProduction(string prod, string remaining) {
        return match(prod, 0, remaining, 0);
    }
    
    bool match(string prod, int pidx, string remaining, int ridx) {
        if(pidx == prod.length()) {
            return ridx == remaining.length();
        }
        
        if(ridx > remaining.length()) {
            return false;
        }
        
        char sym = prod[pidx];
        
        if(isupper(sym)) {
            if(cfg.rules.find(sym) == cfg.rules.end()) {
                return false;
            }
            
            for(string subprod : cfg.rules[sym]) {
                if(subprod == "e" || subprod == "eps") {
                    if(match(prod, pidx + 1, remaining, ridx)) {
                        return true;
                    }
                } else {
                    for(int i = ridx; i <= remaining.length(); i++) {
                        string substr = remaining.substr(ridx, i - ridx);
                        if(tryProduction(subprod, substr)) {
                            if(match(prod, pidx + 1, remaining, i)) {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        } else {
            if(ridx < remaining.length() && remaining[ridx] == sym) {
                return match(prod, pidx + 1, remaining, ridx + 1);
            }
            return false;
        }
    }
};

int main() {
    CFG cfg;
    string filename, input;
    
    cout << "Enter grammar file: ";
    cin >> filename;
    cin.ignore();
    
    cfg.readFile(filename);
    cfg.display();
    
    Parser parser(cfg);
    
    cout << "\nEnter string (exit to quit): ";
    while(getline(cin, input)) {
        if(input == "exit") break;
        
        string test = (input == "e" || input == "eps") ? "" : input;
        
        if(parser.accepts(test)) {
            cout << "ACCEPTED" << endl;
        } else {
            cout << "REJECTED" << endl;
        }
        
        cout << "Enter string (exit to quit): ";
    }
    
    return 0;
}