#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<algorithm>
using namespace std;

struct Grammar {
    map<string, vector<vector<string>>> rules;
    vector<string> nonterms;
    string start;
    
    bool isNonterm(string s) {
        return s.size() == 1 && isupper(s[0]);
    }
    
    bool isEps(string s) {
        return s == "e" || s == "eps";
    }
    
    void loadFile(string filename) {
        ifstream f(filename);
        string line;
        
        while(getline(f, line)) {
            if(line.empty()) continue;
            
            size_t pos = line.find("->");
            if(pos == string::npos) continue;
            
            string lhs = line.substr(0, pos);
            lhs.erase(0, lhs.find_first_not_of(" \t"));
            lhs.erase(lhs.find_last_not_of(" \t") + 1);
            
            if(rules.find(lhs) == rules.end()) {
                nonterms.push_back(lhs);
            }
            
            string rhs = line.substr(pos + 2);
            stringstream ss(rhs);
            string prod;
            
            while(getline(ss, prod, '|')) {
                prod.erase(0, prod.find_first_not_of(" \t"));
                prod.erase(prod.find_last_not_of(" \t") + 1);
                
                vector<string> symbols;
                stringstream ps(prod);
                string sym;
                while(ps >> sym) {
                    symbols.push_back(sym);
                }
                
                if(!symbols.empty()) {
                    rules[lhs].push_back(symbols);
                }
            }
        }
        f.close();
        
        if(!nonterms.empty()) {
            start = nonterms[0];
        }
    }
    
    void display() {
        cout << "\nGrammar:" << endl;
        for(string nt : nonterms) {
            cout << nt << " -> ";
            for(int i = 0; i < rules[nt].size(); i++) {
                if(i > 0) cout << " | ";
                for(int j = 0; j < rules[nt][i].size(); j++) {
                    if(j > 0) cout << " ";
                    cout << rules[nt][i][j];
                }
            }
            cout << endl;
        }
        cout << "Start: " << start << endl;
    }
};

class FFCalculator {
private:
    Grammar& g;
    map<string, set<string>> first;
    map<string, set<string>> follow;
    
public:
    FFCalculator(Grammar& g) : g(g) {
        for(string nt : g.nonterms) {
            first[nt];
            follow[nt];
        }
    }
    
    void compute() {
        computeFirst();
        computeFollow();
    }
    
    void display() {
        cout << "\n===== FIRST Sets =====" << endl;
        for(string nt : g.nonterms) {
            cout << "FIRST(" << nt << ") = { ";
            for(auto f : first[nt]) {
                cout << f << " ";
            }
            cout << "}" << endl;
        }
        
        cout << "\n===== FOLLOW Sets =====" << endl;
        for(string nt : g.nonterms) {
            cout << "FOLLOW(" << nt << ") = { ";
            for(auto f : follow[nt]) {
                cout << f << " ";
            }
            cout << "}" << endl;
        }
    }
    
private:
    void computeFirst() {
        bool changed = true;
        
        while(changed) {
            changed = false;
            
            for(string nt : g.nonterms) {
                int prevSize = first[nt].size();
                
                for(vector<string>& prod : g.rules[nt]) {
                    int i = 0;
                    while(i < prod.size()) {
                        string sym = prod[i];
                        
                        if(g.isEps(sym)) {
                            first[nt].insert("e");
                            break;
                        }
                        
                        if(!g.isNonterm(sym)) {
                            first[nt].insert(sym);
                            break;
                        }
                        
                        // sym is non-terminal
                        bool hasEps = false;
                        for(string f : first[sym]) {
                            if(!g.isEps(f)) {
                                first[nt].insert(f);
                            } else {
                                hasEps = true;
                            }
                        }
                        
                        if(!hasEps) break;
                        i++;
                    }
                }
                
                if(first[nt].size() > prevSize) {
                    changed = true;
                }
            }
        }
    }
    
    void computeFollow() {
        follow[g.start].insert("$");
        
        bool changed = true;
        while(changed) {
            changed = false;
            
            for(string B : g.nonterms) {
                for(vector<string>& prod : g.rules[B]) {
                    for(int k = 0; k < prod.size(); k++) {
                        string A = prod[k];
                        
                        if(!g.isNonterm(A)) continue;
                        
                        int prevSize = follow[A].size();
                        
                        // Add FIRST(beta) - {e} to FOLLOW(A)
                        int i = k + 1;
                        bool hasEps = true;
                        
                        while(i < prod.size() && hasEps) {
                            string sym = prod[i];
                            hasEps = false;
                            
                            if(g.isEps(sym)) {
                                hasEps = true;
                            } else if(!g.isNonterm(sym)) {
                                follow[A].insert(sym);
                                hasEps = false;
                            } else {
                                for(string f : first[sym]) {
                                    if(!g.isEps(f)) {
                                        follow[A].insert(f);
                                    } else {
                                        hasEps = true;
                                    }
                                }
                            }
                            i++;
                        }
                        
                        // If beta =>* e, add FOLLOW(B) to FOLLOW(A)
                        if(hasEps) {
                            for(string f : follow[B]) {
                                follow[A].insert(f);
                            }
                        }
                        
                        if(follow[A].size() > prevSize) {
                            changed = true;
                        }
                    }
                }
            }
        }
    }
};

int main() {
    Grammar g;
    string filename;
    
    cout << "Enter grammar file: ";
    cin >> filename;
    
    g.loadFile(filename);
    g.display();
    
    FFCalculator calc(g);
    calc.compute();
    calc.display();
    
    return 0;
}