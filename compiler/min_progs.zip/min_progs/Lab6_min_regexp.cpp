#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<set>
#include<stack>
using namespace std;

#define EPS -1
#define WIL -2

struct Trans {
    int ch, to;
};

struct St {
    vector<Trans> trans;
    bool acc;
};

struct NFA {
    vector<St> st;
    int start, accept;
    
    int newSt() {
        st.push_back({vector<Trans>(), false});
        return st.size() - 1;
    }
    
    void addTrans(int from, int ch, int to) {
        st[from].trans.push_back({ch, to});
    }
};

struct Frag {
    int s, a;
};

class REParser {
private:
    string re;
    int pos;
    NFA nfa;
    
public:
    REParser(string r) : re(r), pos(0) {
        nfa.st.clear();
        nfa.start = nfa.newSt();
    }
    
    NFA build() {
        Frag f = expr();
        nfa.start = f.s;
        nfa.accept = f.a;
        nfa.st[f.a].acc = true;
        return nfa;
    }
    
private:
    char peek() {
        return pos < re.size() ? re[pos] : '\0';
    }
    
    char consume() {
        return pos < re.size() ? re[pos++] : '\0';
    }
    
    int newSt() {
        return nfa.newSt();
    }
    
    void link(int from, int ch, int to) {
        nfa.addTrans(from, ch, to);
    }
    
    Frag expr() {
        Frag f = concat();
        while(peek() == '|') {
            consume();
            Frag g = concat();
            int s = newSt(), a = newSt();
            link(s, EPS, f.s);
            link(s, EPS, g.s);
            link(f.a, EPS, a);
            link(g.a, EPS, a);
            f = {s, a};
        }
        return f;
    }
    
    Frag concat() {
        Frag f = repeat();
        while(peek() != '\0' && peek() != '|' && peek() != ')') {
            Frag g = repeat();
            link(f.a, EPS, g.s);
            f.a = g.a;
        }
        return f;
    }
    
    Frag repeat() {
        Frag f = atom();
        char op = peek();
        
        if(op == '*') {
            consume();
            int s = newSt(), a = newSt();
            link(s, EPS, f.s);
            link(s, EPS, a);
            link(f.a, EPS, f.s);
            link(f.a, EPS, a);
            return {s, a};
        }
        else if(op == '+') {
            consume();
            int s = newSt(), a = newSt();
            link(s, EPS, f.s);
            link(f.a, EPS, f.s);
            link(f.a, EPS, a);
            return {s, a};
        }
        else if(op == '?') {
            consume();
            int s = newSt(), a = newSt();
            link(s, EPS, f.s);
            link(s, EPS, a);
            link(f.a, EPS, a);
            return {s, a};
        }
        return f;
    }
    
    Frag atom() {
        char c = peek();
        if(c == '(') {
            consume();
            Frag f = expr();
            if(peek() == ')') consume();
            return f;
        }
        consume();
        int s = newSt(), a = newSt();
        if(c == '.') link(s, WIL, a);
        else link(s, (int)c, a);
        return {s, a};
    }
};

class Simulator {
private:
    const NFA& nfa;
    
public:
    Simulator(const NFA& n) : nfa(n) {}
    
    bool accepts(string input) {
        set<int> curr = closure({nfa.start});
        
        for(char ch : input) {
            set<int> next;
            for(int s : curr) {
                for(auto& t : nfa.st[s].trans) {
                    if(t.ch == (int)ch || t.ch == WIL) {
                        next.insert(t.to);
                    }
                }
            }
            curr = closure(next);
            if(curr.empty()) return false;
        }
        
        for(int s : curr) {
            if(nfa.st[s].acc) return true;
        }
        return false;
    }
    
private:
    set<int> closure(set<int> states) {
        set<int> result = states;
        vector<int> work(states.begin(), states.end());
        
        while(!work.empty()) {
            int s = work.back();
            work.pop_back();
            
            for(auto& t : nfa.st[s].trans) {
                if(t.ch == EPS && result.find(t.to) == result.end()) {
                    result.insert(t.to);
                    work.push_back(t.to);
                }
            }
        }
        return result;
    }
};

int main() {
    string filename, re;
    
    cout << "Enter RE file: ";
    cin >> filename;
    cin.ignore();
    
    ifstream f(filename);
    getline(f, re);
    f.close();
    
    cout << "RE: " << re << endl;
    
    REParser parser(re);
    NFA nfa = parser.build();
    Simulator sim(nfa);
    
    cout << "NFA states: " << nfa.st.size() << endl;
    cout << "\nEnter string (exit to quit): ";
    
    string input;
    while(getline(cin, input)) {
        if(input == "exit") break;
        
        if(sim.accepts(input)) {
            cout << "ACCEPTED" << endl;
        } else {
            cout << "REJECTED" << endl;
        }
        
        cout << "Enter string (exit to quit): ";
    }
    
    return 0;
}