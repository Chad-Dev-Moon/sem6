#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<set>
using namespace std;

struct Prod {
    char left;
    string right;
};

class RG {
private:
    set<char> nonTerm;
    set<char> term;
    char start;
    vector<Prod> prod;

public:
    void readFile(string filename) {
        ifstream f(filename);
        int n, m, p;
        
        f >> n;
        for(int i = 0; i < n; i++) {
            char c;
            f >> c;
            nonTerm.insert(c);
        }
        
        f >> m;
        for(int i = 0; i < m; i++) {
            char c;
            f >> c;
            term.insert(c);
        }
        
        f >> start;
        
        f >> p;
        for(int i = 0; i < p; i++) {
            char l;
            string arrow, r;
            f >> l >> arrow >> r;
            prod.push_back({l, r});
        }
        
        f.close();
    }
    
    void display() {
        cout << "\nGrammar:" << endl;
        cout << "Non-terminals: ";
        for(char c : nonTerm) cout << c << " ";
        cout << endl;
        
        cout << "Terminals: ";
        for(char c : term) cout << c << " ";
        cout << endl;
        
        cout << "Start: " << start << endl;
        cout << "Productions:" << endl;
        for(auto& p : prod) {
            cout << "  " << p.left << " -> " << p.right << endl;
        }
    }
    
    bool accepts(string input) {
        return parse(start, input, 0);
    }
    
private:
    bool parse(char sym, string input, int pos) {
        if(pos == input.length()) return false;
        
        for(auto& p : prod) {
            if(p.left != sym) continue;
            
            int newPos = match(p.right, input, pos);
            if(newPos != -1 && newPos == input.length()) {
                return true;
            }
        }
        return false;
    }
    
    int match(string production, string input, int pos) {
        int i = 0;
        while(i < production.length() && pos < input.length()) {
            if(term.find(production[i]) != term.end()) {
                if(input[pos] != production[i]) return -1;
                pos++;
            } else {
                if(parse(production[i], input, pos)) {
                    return input.length();
                }
                return -1;
            }
            i++;
        }
        return pos;
    }
};

int main() {
    RG grammar;
    string filename, input;
    
    cout << "Enter grammar file: ";
    cin >> filename;
    
    grammar.readFile(filename);
    grammar.display();
    
    cout << "\nEnter string (quit to exit): ";
    cin >> input;
    
    while(input != "quit") {
        if(grammar.accepts(input)) {
            cout << "ACCEPTED" << endl;
        } else {
            cout << "REJECTED" << endl;
        }
        cout << "Enter string (quit to exit): ";
        cin >> input;
    }
    
    return 0;
}