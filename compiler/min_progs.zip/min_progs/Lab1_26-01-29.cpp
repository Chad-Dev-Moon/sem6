#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <vector>

using namespace std;

class DFA {
private:
    set<string> states;
    set<char> alphabet;
    map<pair<string, char>, string> transitions;
    string startState;
    set<string> finalStates;

public:
    bool readFromFile(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "Error: Could not open file " << filename << endl;
            return false;
        }

        int numStates, numAlphabet, numTransitions, numFinalStates;

        file >> numStates;
        for (int i = 0; i < numStates; i++) {
            string state;
            file >> state;
            states.insert(state);
        }

        file >> numAlphabet;
        for (int i = 0; i < numAlphabet; i++) {
            char symbol;
            file >> symbol;
            alphabet.insert(symbol);
        }

        file >> startState;

        file >> numFinalStates;
        for (int i = 0; i < numFinalStates; i++) {
            string state;
            file >> state;
            finalStates.insert(state);
        }

        file >> numTransitions;
        string fromState, toState;
        char symbol;
        for (int i = 0; i < numTransitions; i++) {
            file >> fromState >> symbol >> toState;
            transitions[make_pair(fromState, symbol)] = toState;
        }

        file.close();
        return true;
    }

    bool accepts(const string& input) {
        string currentState = startState;

        for (char symbol : input) {
            if (alphabet.find(symbol) == alphabet.end()) {
                cout << "Error: Symbol '" << symbol << "' not in alphabet" << endl;
                return false;
            }

            auto transition = transitions.find(make_pair(currentState, symbol));
            if (transition == transitions.end()) {
                return false;
            }

            currentState = transition->second;
        }

        return finalStates.find(currentState) != finalStates.end();
    }

    void display() {
        cout << "\n=== DFA Information ===" << endl;

        cout << "States: ";
        for (const auto& state : states) {
            cout << state << " ";
        }
        cout << endl;

        cout << "Alphabet: ";
        for (char symbol : alphabet) {
            cout << symbol << " ";
        }
        cout << endl;

        cout << "Start State: " << startState << endl;

        cout << "Final States: ";
        for (const auto& state : finalStates) {
            cout << state << " ";
        }
        cout << endl;

        cout << "\nTransitions:" << endl;
        for (const auto& transition : transitions) {
            cout << "  (" << transition.first.first << ", " 
                 << transition.first.second << ") -> " 
                 << transition.second << endl;
        }
        cout << "======================\n" << endl;
    }
};

int main() {
    DFA dfa;
    string filename;

    cout << "Enter the DFA file name: ";
    cin >> filename;

    if (!dfa.readFromFile(filename)) {
        return 1;
    }

    dfa.display();

    string input;
    cout << "Enter a string to check (or 'quit' to exit): ";
    cin >> input;

    while (input != "quit") {
        if (dfa.accepts(input)) {
            cout << "ACCEPTED: The string \"" << input << "\" is accepted by the DFA." << endl;
        } else {
            cout << "REJECTED: The string \"" << input << "\" is rejected by the DFA." << endl;
        }

        cout << "\nEnter a string to check (or 'quit' to exit): ";
        cin >> input;
    }

    cout << "Exiting Program !" << endl;
    return 0;
}